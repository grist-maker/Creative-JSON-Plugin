<?php
//Here, we define a field generator, which actually places the fields and corresponding labels in different div elements
function json_generator_fields( $args )
{
    //This sets the ID, which is used to reference each specific value to check content and print it for the user
    $id    = isset( $args['id'] )    ? $args['id']    : ''; //ternary operator if first is true then
    //The label is used to prompt the user, telling them what is being set
    $label = isset( $args['label'] ) ? $args['label'] : '';
    //Value is wiped, replaced with whatever value was sent in (in this case, empty string)
    $value = isset( $args['value'] ) ? $args['value']: '';
    //We print two new div elements, one to label the field, one to show the field
    echo '<div class = "TextLabel"><strong><label for = "">'. $label .'</label></strong></div>';
    echo '<div class = "TextField"><input id="'. $id .'" name="'.$id.'" type="text" size="40" value="'. $value .'"></div><br />';
}