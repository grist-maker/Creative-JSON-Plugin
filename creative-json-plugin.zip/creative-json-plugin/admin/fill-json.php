<?php

//Next, we want to print the actual schema in the proper format. This does not have error checking, as it is assumed that
//the user will not enter incorrect data, and we can not predict what value is appropriate based on the creative work in
//question, unlike with email or phone number formatting which is consistent.
function print_json_schema()
{
    //We check to make sure that the values are at least set, that is, the submit button has been pressed at some point.
    if ($_POST != null) {
        //We start with the entry bracket and a blank line.
        echo("<p>{ </p>");
        //Next, the context field to provide the JSON formatting used
        echo("<p>\"@context\": \"http://schema.org\"");
        //We then enter similar isset if statements each time, printing each field only if it has been filled
        if(isset ($_POST['Type']) && $_POST['Type'] != '')
        {
            //This prints a closing comma on the prior line, ONLY if some later field is full too. In this way, the following
            //comma is printed only if something (regardless of field) follows it. This prevents unneeded comma addition.
            echo ",</p>";
            //Next, we print the property name, enclosed in quotes, followed by the user-entered value.
            echo("<p>\"@type\": " . "\"" . $_POST['Type'] . "\"");
        }
        if (isset($_POST['Abstract']) && $_POST['Abstract'] != '') {
            echo ",</p>";
            echo("<p>\"abstract\": " . "\"" . $_POST['Abstract'] . "\"");
        }
        if (isset($_POST['CopyrightYear']) && $_POST['CopyrightYear'] != '') {
            echo ",</p>";
            echo("<p>\"copyrightYear\": " . "\"" . $_POST['CopyrightYear'] . "\"");
        }
        if (isset($_POST['CopyrightHolder'])&& $_POST['CopyrightHolder'] != '') {
            echo ",</p>";
            echo("<p>\"copyrightHolder\": " . "\"" . $_POST['CopyrightHolder'] . "\"");
        }
        if (isset($_POST['CountryOrigin'])&& $_POST['CountryOrigin'] != '') {
            echo ",</p>";
            echo("<p>\"countryOfOrigin\": " . "\"" . $_POST['CountryOrigin'] . "\"");
        }
        if (isset($_POST['Creator']) && $_POST['Creator']) {
            echo ",</p>";
            echo("<p>\"creator\": " . "\"" . $_POST['Creator'] . "\"");
        }
        if (isset($_POST['DatePublished']) && $_POST['DatePublished'] != '') {
            echo ",</p>";
            echo("<p>\"datePublished\": " . "\"" . $_POST['DatePublished'] . "\"");
        }
        if (isset($_POST['Genre']) && $_POST['Genre'] != '') {
            echo ",</p>";
            echo("<p>\"genre\": " . "\"" . $_POST['Genre'] . "\"");
        }
        if (isset($_POST['Keywords']) && $_POST['Keywords'] != '') {
            echo ",</p>";
            echo("<p>\"keywords\": " . "\"" . $_POST['Keywords'] . "\"");
        }
        if (isset($_POST['LocationCreated']) && $_POST['LocationCreated'] != '') {
            echo ",</p>";
            echo("<p>\"locationCreated\": " . "\"" . $_POST['LocationCreated'] . "\"");
        }
        if (isset($_POST['Producer']) && $_POST['Producer'] != '') {
            echo ",</p>";
            echo("<p>\"producer\": " . "\"" . $_POST['Producer'] . "\"");
        }
        if (isset($_POST['Publisher'])&& $_POST['Publisher'] != '') {
            echo ",</p>";
            echo("<p>\"publisher\": " . "\"" . $_POST['Publisher'] . "\"");
        }
        if (isset($_POST['Name'])&& $_POST['Name'] != '') {
            echo ",</p>";
            echo("<p>\"name\": " . "\"" . $_POST['Name'] . "\"");
        }
        if (isset($_POST['Description'])&& $_POST['Description'] != '') {
            echo ",</p>";
            echo("<p>\"description\": " . "\"" . $_POST['Description'] . "\"");
        }
        //We end by closing the last opened field
        echo("</p>");
        //Then, we print the closing brace
        echo("<p>} </p>");
    }
}