<?php
//Defines the show page function, which will deal with HTML formatting and field generation. It references a function defined in
//field-create.php
function show_page()
{
    ?>
    <div class="wrap">
    <h1><?php echo esc_html( get_admin_page_title(['id' => 'Abstract', 'label' => 'Abstract', 'value' => '']) ); ?></h1>
    <form method="post">

    <?php
    //We generate each field, all of them being textbox entry fields
    json_generator_fields(['id' => 'Type', 'label' => 'Type', 'value' => '']);
    json_generator_fields(['id' => 'Abstract', 'label' => 'Abstract', 'value' => '']);
    json_generator_fields(['id' => 'CopyrightYear', 'label' => 'Copyright Year', 'value' => '']);
    json_generator_fields(['id' => 'CopyrightHolder', 'label' => 'Copyright Holder', 'value' => '']);
    json_generator_fields(['id' => 'CountryOrigin', 'label' => 'Country of Origin', 'value' => '']);
    json_generator_fields(['id' => 'Creator', 'label' => 'Creator', 'value' => '']);
    json_generator_fields(['id' => 'DatePublished', 'label' => 'Date Published', 'value' => '']);
    json_generator_fields(['id' => 'Genre', 'label' => 'Genre', 'value' => '']);
    json_generator_fields(['id' => 'Keywords', 'label' => 'Keywords (comma separated list)', 'value' => '']);
    json_generator_fields(['id' => 'LocationCreated', 'label' => 'Location Created', 'value' => '']);
    json_generator_fields(['id' => 'Producer', 'label' => 'Producer', 'value' => '']);
    json_generator_fields(['id' => 'Publisher', 'label' => 'Publisher', 'value' => '']);
    json_generator_fields(['id' => 'Name', 'label' => 'Name', 'value' => '']);
    json_generator_fields(['id' => 'Description', 'label' => 'Description', 'value' => '']);
    // submit button
    submit_button();
    //We print the actual schema at the bottom if information was entered previously
    print_json_schema();
    ?>

</form>
</div>
    <?php
}
//This makes the actual menu, the icon and page to access the functionality
function make_json_menu()
{
    //We add the menu page here, as shown, and it appears with its own icon on the admin's sidebar.
    add_menu_page
    (
        'JSON Query Generator',
        'JSON Query',
        'manage_options',
        'JSONGenerator',
        'show_page'
    );
    //We register two scripts: field-create.php and json-generator-plugin.php here
    wp_register_script('field-create.php', 'admin/field-create.php');
    wp_register_script('json-generator-plugin.php', 'json-generator-plugin.php');

    //If on this page, we actually display its content as needed.
    if(is_page('JSONGenerator'))
    {
        add_action( 'admin_init', 'show_page' );
    }
}