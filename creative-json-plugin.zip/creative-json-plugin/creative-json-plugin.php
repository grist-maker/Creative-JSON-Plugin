<?php
/**
 * Plugin Name: Creative JSON Plugin
 * Description: An automated generator for a variety of creative work JSONs.
 * Plugin URI:
 * Authors: Gabrielle Tristani, Dylan Gartin, Charles Ross
 * Author URI:
 * Version: 1.1.1
 * License: GPLv2
 * Requires at least: 5.8
 * Requires PHP: 7.0
*/

// exit if file is called directly
if ( ! defined('ABSPATH'))
{
    exit;
}

if(is_admin())
{
    //Install needed dependencies
    require_once plugin_dir_path(__FILE__) . 'admin/field-create.php';
    require_once plugin_dir_path(__FILE__) . 'admin/fill-json.php';
    require_once plugin_dir_path(__FILE__) . 'admin/present-page.php';
}

//Adds one action to make the menu.
add_action( 'admin_menu', 'make_json_menu' );
